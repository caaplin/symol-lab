#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mqueue.h>
#include <fcntl.h>

#define LOG_QUEUE "/pambu_log"
#define MAX_MESSAGE 256

int main(void)
{
    struct mq_attr attr = {
        .mq_flags = 0,
        .mq_maxmsg = 10,
        .mq_msgsize = MAX_MESSAGE,
        .mq_curmsgs = 0,
    };

    mq_unlink(LOG_QUEUE);

    mqd_t q = mq_open(LOG_QUEUE, O_CREAT | O_RDONLY, 0666, &attr);
    if (q == (mqd_t)-1) { perror("logger: mq_open"); return 1; }

    printf("logger: waiting on %s\n", LOG_QUEUE);
    fflush(stdout);

    char buf[MAX_MESSAGE];
    while (1) {
        ssize_t n = mq_receive(q, buf, MAX_MESSAGE, NULL);
        if (n < 0) { perror("logger: mq_receive"); break; }
        buf[n] = '\0';
        printf("LOG: %s\n", buf);
        fflush(stdout);
    }

    mq_close(q);
    mq_unlink(LOG_QUEUE);
    return 0;
}
